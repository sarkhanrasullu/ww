﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class LetterControlButtonLineScript : MonoBehaviour
{ 
    public new Camera camera = null;
    public float depth = 5;
    public LineRenderer lineRenderer;
    private Vector3? lineStartPoint;

    public int sortingOrder = 1;
    public string sortingLayer = "Line";
    public Image btn;
    // Start is called before the first frame update
    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
    }
 
    public Vector3 begin;
    public Vector3 end;

    public float width = 1;
    public float widthEnd = 1;

    // Update is called once per frame
    void Update()
    {
        lineRenderer.sortingLayerName = sortingLayer;
        lineRenderer.sortingOrder = sortingOrder;   
        // if(!btn.interactable){
            var lineEndPoint = GetMouseCameraPoint();

            begin = btn.transform.position;
            begin.z = 0;
            // begin.x = begin.x -x;
            // begin.y = begin.y -y;

            end = lineEndPoint.Value;
            end.z = 0;

            // float radius = 11;
            // if(begin.x < end.x) {
            //     begin.x = begin.x + radius;
            //     begin.y = begin.y - radius;
            // }
            lineRenderer.SetPositions(new Vector3[] { begin, end });
            
            lineRenderer.startWidth = width;
            lineRenderer.endWidth = widthEnd;
        // } else {
        //     // lineRenderer.startWidth = 0;
        //     // lineRenderer.endWidth = 0;
        // }

        if(begin !=null && end !=null){
              lineRenderer.SetPositions(new Vector3[] { begin, end });
              lineRenderer.startWidth = width;
            lineRenderer.endWidth = widthEnd;
        }
    }
 
    private Vector3? GetMouseCameraPoint()
    {
        var ray = camera.ScreenPointToRay(Input.mousePosition);
        return ray.origin + ray.direction * depth;
    }
}
