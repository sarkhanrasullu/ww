using UnityEngine;
using System.Collections;

namespace OwnUtility {
    public class GridUtility{
        public static ArrayList instantiateElements(Transform transform, GameObject prefab, int numberToCreate){
            ArrayList instantiatedObjects = new ArrayList();
            for (int i = 0; i < numberToCreate; i++)
            {
                // Create new instances of our prefab until we've created as many as we specified
               GameObject obj = Object.Instantiate(prefab, transform);
               instantiatedObjects.Add(obj);
            }

            return instantiatedObjects;
        }
    }

    public class Word {
        private ArrayList letters = new ArrayList();
    }
}
