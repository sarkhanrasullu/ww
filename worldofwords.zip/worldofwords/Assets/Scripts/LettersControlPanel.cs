﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class LettersControlPanel : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Button[] buttons = GetComponentsInChildren<Button>();
        foreach(Button button in buttons){
            button.interactable = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
