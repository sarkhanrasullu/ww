﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class LetterControlButtonScript : MonoBehaviour
{ 
    public new Camera camera = null;
    private float depth = 5;
    private Vector3? lineStartPoint;

    private Button btn;
    // Start is called before the first frame update
    void Start()
    {
        btn = GetComponent<Button>();
    }

    // Update is called once per frame
    void Update()
    {
        if(!btn.interactable){
            var lineEndPoint = GetMouseCameraPoint();
        } 
    }

    public void clickEvent()
    {
        lineStartPoint = GetMouseCameraPoint();
        Button b = GetComponent<Button>();
        b.interactable = false;
        Debug.Log("clickEvent");
    }

    public void releaseEvent()
    {
        Debug.Log("releaseEvent");
        Button b = GetComponent<Button>();
        b.interactable = true;
    }

    public void pointerEnterEvent()
    {
        Debug.Log("pointerEnterEvent");
    }

    private Vector3? GetMouseCameraPoint()
    {
        var ray = camera.ScreenPointToRay(Input.mousePosition);
        return ray.origin + ray.direction * depth;
    }
}
