﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
// using OwnUtility;


public class LetterPanelScript : MonoBehaviour
{
    public Button button;

    private ArrayList buttons = new ArrayList();

    private void initializeAllCell()
    {
        GridLayoutGroup grid = GetComponent<GridLayoutGroup>();
        for (int y = 0; y < 5; y++)
        {
            ArrayList buttonsX = new ArrayList();
            for (int x = 0; x < 7; x++)
            {
                Button obj = Object.Instantiate(button, new Vector3(0, 0, 1), Quaternion.identity, grid.transform);
                obj.interactable = false;
                
                hideButton(obj);
                buttonsX.Add(obj);
            }
            buttons.Add(buttonsX);
        }
    }


    private void showButtonDisabled(Button btn)
    {
        Color txtc = btn.GetComponentInChildren<Text>().color;
        txtc.a = 0;
        btn.GetComponentInChildren<Text>().color = txtc;

        Color c = btn.GetComponent<Image>().color;
        c.a = 1;
        btn.GetComponent<Image>().color = c;
        btn.interactable = false;
    }

    private void showButtonFound(Button btn)
    {
        showButtonDisabled(btn);
        Color txtc = btn.GetComponentInChildren<Text>().color;
        txtc.a = 1;
        btn.GetComponentInChildren<Text>().color = txtc;
        btn.interactable = true;
    }

    private void hideButton(Button btn)
    {
        Color c = btn.GetComponent<Image>().color;
        c.a = 0;
        btn.GetComponent<Image>().color = c;
    }

     ArrayList words = new ArrayList();
        

    void Start()
    {
        words.Add("QARA");
        words.Add("ATA");
        words.Add("QART");
        words.Add("ARAQ");
        words.Add("QATAR");
        words.Add("TAR");

        initializeAllCell();

        prepareTemplate();
    }

    private void prepareTemplate(){
         prepareText("QART", 2, 0, 1);
         prepareText("ATA", 0, 1, 1);
         prepareText("TAR",4 , 2, 1);
         prepareText("QARA", 1, 3, 1);


         prepareText("ARAQ", 2, 3, 0);
         prepareText("QATAR", 4, 4, 0);
    }
 
    private Button getButton(int x, int y)
    {
        Debug.Log("y="+y+",buttons.count="+buttons.Count);
        if (y >= buttons.Count) return null;
        ArrayList arr = (ArrayList)buttons[buttons.Count-1-y];
        Debug.Log("arr.size="+arr.Count);
        if (x >= arr.Count) return null;
        Button btn = (Button)arr[x];
        return btn;
    }

    private void prepareText(string text, int x, int y, int direction)
    {
        char[] symbols = text.ToCharArray();
        
        for (int i = 0; i < symbols.Length; i++)
        {
            char c = symbols[i];
            Debug.Log("x=" + x + ",y=" + y+",direction="+direction+",text="+text);
            Button b = getButton(x, y);
            if (b == null) break;
            if (direction == 1)
            {
                x++;
            }
            else
            {
                y--;
            }
            b.GetComponentInChildren<Text>().text = c + "";
            // showButtonFound(b);
            showButtonDisabled(b);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}